function score=fss_score(qfit,obsdata,W,w_user,new_calc,tmp_str,vars_2d,vars_sound)
% NAME
%   rmse_score
% PURPOSE
%   calculate RMSE-type score for Meta-Model predictions (regressions estimations)
% INPUTS
%   qfit - metamodel predictions for given parameter combination
%   obsdata - observations data
%   W - weights for different fields, to equalize their contributions to the final score
%   w_user - array of user defined weights (for simlicity - from 0 to 1) for calibrated fields
%   new_calc - 0 or 1: 0 by default, when main_data is devided into cells over periods. 1 - otherwise
%   tmp_str - is the temporary data folder which are being used
% OUTPUT
%   score - RMSE-type score
% AUTHOR
%   Pavel Khain (pavelkh_il@yahoo.com)

global load_period
Stotal=0; % accumlated sum of S
Ntotal=0; % accumlated sum of number of existed S multiple by w_user
load([tmp_str(9:end),'/grid_datamatrix.mat']) % the grid datamatrix
load([tmp_str(9:end),'/calmo_matrix_2D_size.mat']) % the calmo size of the the domain
nstep=2; % the number of grid point for each of the 4 wind direction to take into the interpolation
th=0.1; % the thershold for precipiation in mm

if new_calc==1
    i=0;
    for type=1:length(obsdata)
        std_days{type}=nanstd(obsdata{type},1,2);
        std_days{type}=repmat(std_days{type},1,size(obsdata{type},2));
        if(type==1)
            for j=1:size(obsdata{type},1)
                i=i+1;
                S(i)=0;
                if w_user(i)~=0
                    if ~strcmp(vars_2d{j},'pr') % where the field is rain
                        tmp_mod=squeeze(qfit{type}(j,:,:));
                        tmp_obs=squeeze(obsdata{type}(j,:,:));
                        tmp_std=squeeze(std_days{type}(j,:,:));
                        S(i)=(w_user(i)./W{type}(j)).*nanmean(((tmp_mod(:)-tmp_obs(:))./tmp_std(:)).^2);
                    else
                        clear mat_obs mat_mod
                        FSSup=0;
                        FSSdown=0;
                        for day=1:size(qfit{type},2)
                            clear mat mat2
                            mat=squeeze(obsdata{type}(j,day,:));
                            mat_obs{i}=binary_domain(mat,grid_datamatrix,th,nstep,calmo_matrix_2D_size);
                            mat2=squeeze(qfit{type}(j,day,:));
                            mat_mod{i}=binary_domain(mat2,grid_datamatrix,th,nstep,calmo_matrix_2D_size);
                            display(['finishing day number ',num2str(i)])
                            FSSup=FSSup+nansum((mat_obs{i}(:)-mat_mod{i}(:)).^2);
                            FSSdown=FSSdown+(nansum(mat_obs{i}(:).^2)+nansum(mat_obs{i}(:).^2));
                        end
                        S(i)=(w_user(i)./W{type}(j)).*(1-FSSup/FSSdown);
                        Stotal=Stotal+S(i);
                        Ntotal=Ntotal+w_user(i);
                    end
                end
            end
        else
            for j=1:size(obsdata{type},1)
                i=i+1;
                S(i)=0;
                if w_user(i)~=0
                    if ~strcmp(vars_2d{j},'pr') % where the field is rain
                        tmp_mod=squeeze(qfit{type}(j,:,:));
                        tmp_obs=squeeze(obsdata{type}(j,:,:));
                        tmp_std=squeeze(std_days{type}(j,:,:));
                        S(i)=(w_user(i)./W{type}(j)).*nanmean(((tmp_mod(:)-tmp_obs(:))./tmp_std(:)).^2);
                    else
                        clear mat_obs mat_mod
                        FSStemp=0;
                        for day=1:size(qfit{type},2)
                            clear mat mat2
                            FSSup=0;
                        FSSdown=0;
                            mat=squeeze(obsdata{type}(j,day,:));
                            mat2=squeeze(qfit{type}(j,day,:));
                                mat_obs=[]; 
                                mat_mod=[]; 
                            [mat_obs, mat_mod]=binary_domain2(mat,mat2,grid_datamatrix,th,nstep,calmo_matrix_2D_size);
                            display(['finishing day number ',num2str(i)])
                            FSSup=FSSup+nansum((mat_obs(:)-mat_mod(:)).^2);
                            FSSdown=FSSdown+(nansum(mat_obs(:).^2)+nansum(mat_obs(:).^2));
                            SStemp=FSStemp+(1-FSSup/FSSdown);
                            
                        end
                         FSStemp=FSStemp/size(qfit{type},2);
                         S(i)=(w_user(i)./1).*FSStemp;
                    end
                    if(~isnan(S(i)))
                        Stotal=Stotal+S(i);
                        Ntotal=Ntotal+w_user(i);
                    end
                end
            end
        end
    end
    score=sqrt(Stotal/Ntotal);
else
    %    for mm=load_period
    for mm=1:1
        i=0;
        for type=1:length(obsdata{mm})
            std_days{mm}{type}=nanstd(obsdata{mm}{type},1,2);
            std_days{mm}{type}=repmat(std_days{mm}{type},1,size(obsdata{mm}{type},2));
            for j=1:size(obsdata{mm}{type},1)
                i=i+1;
                S(i)=0;
                if w_user(i)~=0
                    %j
                    
                    if(type==1)
                        if (~strcmp(vars_2d{j},'pr')) % where the field is rain
                            tmp_mod=squeeze(qfit{mm}{type}(j,:,:));
                            tmp_obs=squeeze(obsdata{mm}{type}(j,:,:));
                       %     tmp_str
                            %check that std is not zero!
                            tmp_std=squeeze(std_days{mm}{type}(j,:,:));
                            %whos S j i mm  W
                            % W{1}{2}
                            % S(i)=(w_user(i)./W{mm}{type}(j)).*(1-nanmean(((tmp_mod(:)-tmp_obs(:))./tmp_std(:)).^2));
                            %if length(W{mm})>1
                            %    length(W{mm})
                            %    S(i)=(w_user(i)./W{mm}{type}(j)).*(1-nanmean(((tmp_mod(:)-tmp_obs(:))./tmp_std(:)).^2));
                            %else
                            S(i)=(w_user(i)./1).*(1-nanmean(((tmp_mod(:)-tmp_obs(:))./tmp_std(:)).^2));
                            %end
                        else
                            clear mat_obs mat_mod
                           FSStemp=0;
                           size(qfit{mm}{type},2)
                            for day=1:size(qfit{mm}{type},2)
                                 FSSup=0;
                            FSSdown=0;
                     %           disp(['this is the day ',num2str(day),' out of ',num2str(size(qfit{mm}{type},2)),' days'])
                                clear mat mat2
                                mat=squeeze(obsdata{mm}{type}(j,day,:));
                                 mat2=squeeze(qfit{mm}{type}(j,day,:));
                              %  calmo_matrix_2D_size
                               % whos mat grid_datamatrix th nstep calmo_matrix_2D_size
                               mat_obs=[]; 
                                mat_mod=[]; 
                              day
                               [mat_obs, mat_mod]=binary_domain2(mat,mat2,grid_datamatrix,th,nstep,calmo_matrix_2D_size);
                                
                              ; 
                               % whos mat grid_datamatrix th nstep calmo_matrix_2D_size
                              
                                                    
                               
                     %           disp(['finishing day number ',num2str(day),' in type number ',num2str(type),' and j field is ',num2str(j),'   ',vars_2d(j)])
                              FSSup=FSSup+nansum((mat_obs(:)-mat_mod(:)).^2);
                               FSSdown=FSSdown+(nansum(mat_obs(:).^2)+nansum(mat_obs(:).^2));                            %{
                           
                            kk=[];
                            kk=find(~isnan(mat_obs(:)));
                            kk2=[];
                            kk2=find(~isnan(mat_mod(:)));
                            length(kk2)
                            length(kk)
                            AA=kk2-kk;
                            dsss=sum(AA);
                            if(abs(dsss>0.1))
                                stopstopstop
                            end
                                                     
                                FSStemp=FSStemp+(2*nansum(mat_obs(:).*mat_mod(:)))/(nansum(mat_obs(:).^2)+nansum(mat_mod(:).^2))
                           end
                            display('size')
                            size(qfit{mm}{type},2)
                            FSStemp=FSStemp/size(qfit{mm}{type},2)
                            S(i)=(w_user(i)./1).*FSStemp;
                            %S(i)=(w_user(i)./W{mm}{type}(j)).*(1-FSSup/FSSdown);
                        end
                    elseif(type==2)
                        tmp_mod=squeeze(qfit{mm}{type}(j,:,:));
                        tmp_obs=squeeze(obsdata{mm}{type}(j,:,:));
                   %check that std is not zero!
                        tmp_std=squeeze(std_days{mm}{type}(j,:,:));
                  %      whos S j i mm  W
                        % W{1}{2}
                        % S(i)=(w_user(i)./W{mm}{type}(j)).*(1-nanmean(((tmp_mod(:)-tmp_obs(:))./tmp_std(:)).^2));
                        %if length(W{mm})>1
                        %    length(W{mm})
                        %    S(i)=(w_user(i)./W{mm}{type}(j)).*(1-nanmean(((tmp_mod(:)-tmp_obs(:))./tmp_std(:)).^2));
                        %else
                        S(i)=(w_user(i)./1).*(1-nanmean(((tmp_mod(:)-tmp_obs(:))./tmp_std(:)).^2));
                        %end
                      %  disp(['finishing day number ',num2str(day),' in type number ',num2str(type),' and j field is ',num2str(j),'   ',vars_sound(j)])
                    end
                    if(length(mm)>=2)
                        if(~isnan(S(mm,i)))
                            Ntotal=Ntotal+w_user(i);
                            Stotal=Stotal+S(mm,i);
                        end
                    elseif(length(mm)==1)
                        if(~isnan(S(i)))
                            Ntotal=Ntotal+w_user(i);
                            Stotal=Stotal+S(i);
                        end
                    end
                end
            end
        end
    end
    score=sqrt(Stotal/Ntotal);
end




