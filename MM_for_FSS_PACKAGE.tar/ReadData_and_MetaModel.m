function ReadData_and_MetaModel(date_min,date_max)

% NAME 
%   ReadData_and_MetaModel
% PURPOSE 
%   Read observations and simulations data, then fit the Meta-Models
% INPUTS 
%   time period: from date_min 'dd-mmm-yyyy' to date_max 'dd-mmm-yyyy'
% OUTPUTS 
%   saved (in .mat format) observations and simulations fields as well as
%   the Meta-Models coefficients
% AUTHOR  
%   Pavel Khain (pavelkh_il@yahoo.com)

%clear all;

date_lim=struct('dmax',date_max,'dmin',date_min);
tmp_str=datestr(date_min);
mkdir(tmp_str);

%------------------------------------------------------------
%-1
% NAME 
%   ReadData_and_MetaModel
% PURPOSE 
%   Read observations and simulations data, then fit the Meta-Models
% INPUTS 
%   time period: from date_min 'dd-mmm-yyyy' to date_max 'dd-mmm-yyyy'
% OUTPUTS 
%   saved (in .mat format) observations and simulations fields as well as
%   the Meta-Models coefficients
% AUTHOR  
%   Pavel Khain (pavelkh_il@yahoo.com)

%clear all;

date_lim=struct('dmax',date_max,'dmin',date_min);
tmp_str=datestr(date_min);
mkdir(tmp_str);

%------------------------------------------------------------
%-1- namelist:
%------------------------------------------------------------
%clear global comp maindir curdir simuldir;
global comp maindir curdir simuldir obsdir extdir;

[period_len maindir simuldir obsdir extdir vars vars_2d avg_fields vars_sound sims_opt ml score w_user lhacc iterations_num best_percent date_min_tot date_max_tot]=namelist();
%------------------------------------------------------------
%-4- Define "parameters" structure
%------------------------------------------------------------

[paramn,paramnt,range,default,expval,valval,simval,sims_reg,sims_inter,sims_con,valcon,param_log,date_min_check,date_max_check]=sims_def(sims_opt);
if datenum(date_min)<datenum(date_min_check) || datenum(date_max)>datenum(date_max_check)
    stop
end
parameters=struct('name',paramn,'range',range','default',default,'experiments', ...
    expval,'constrain',valcon,'validation',valval,'name_tex',paramnt);
    
    
run_again=0;
run_again=1;
if run_again==1
    %------------------------------------------------------------
    %-5- Define "datamatrix" structure
    %------------------------------------------------------------
    
    % (1) Read observations
    display('Read obs')
    [datamatrix.obsdata datamatrix_s.obsdata datamatrix_s.sound_exist]=read_calmo_obs(vars,date_lim,'clever_mean',length(vars_sound));
    
    % (2) Read reference simulation
    sims={'DEF'};
    [datamatrix.refdata datamatrix_s.refdata]=read_calmo_sim(vars,sims,date_lim,datamatrix_s.sound_exist,length(vars_sound));
    %}
        % (3) Read parameter experiments
    [datamatrix.moddata datamatrix_s.moddata]=read_calmo_sim(vars,sims_reg,date_lim,datamatrix_s.sound_exist,length(vars_sound));
    %size: 3-CAPE,SIN,TCWC    29-number of days    st 8- 3h steps in a day  59-number of r.s. station

    % (4) Read interaction parameter experiments
    par_num=length(paramn);
    if ~strcmp(sims_inter,'MISSING') % IN CASE THERE ARE INTERACTION TERMS:
        [datamatrix.moddata(:,:,2*par_num+1:2*par_num+length(sims_inter),:,:) datamatrix_s.moddata(:,:,2*par_num+1:2*par_num+length(sims_inter),:,:)]=read_calmo_sim(vars,sims_inter,date_lim,datamatrix_s.sound_exist,length(vars_sound));
    end
    %}
    % (5) Read validation experiments
    %if ~strcmp(simval,'MISSING')
    %    datamatrix.valdata=read_calmo_sim(vars,simval,date_lim);
    %end
    
    % (6) Read constrain experiments
    if ~strcmp(sims_con,'MISSING') % IN CASE THERE ARE CONSTRAIN (INTERMEDIATE) SIMULATIONS:
        [datamatrix.constrain datamatrix_s.constrain]=read_calmo_sim(vars,sims_con,date_lim,datamatrix_s.sound_exist,length(vars_sound));
    end
    
 
    
    if ~isempty(strfind([vars{:}],'pr')) || ~isempty(strfind([vars{:}],'t2m_avg')) || ~isempty(strfind([vars{:}],'t2m_max')) || ~isempty(strfind([vars{:}],'t2m_min')) ...
        || ~istempty(strfind([vars{:}],'td2m_avg')) || ~istempty(strfind([vars{:}],'td2m_max')) || ~isempty(strfind([vars{:}],'td2m_min')) || ~isempty(strfind([vars{:}],'sunshine')) 
        % if the surf. obs. number for given field,i,j (usually per month) is <3, cancel the entire month
        for f=1:size(datamatrix.obsdata,1)
            f
            for i=1:size(datamatrix.obsdata,4)
               
                for j=1:size(datamatrix.obsdata,5)
                    if sum(~isnan(squeeze(datamatrix.obsdata(f,:,1,i,j))))<3
                        datamatrix.obsdata(f,1:end,1,i,j)=NaN;
                    end
                end
            end
        end
         
        % cancel all the missing Italian grid-points:
        [a]=isnan(datamatrix.obsdata);
        datamatrix.refdata(a==1)=NaN;
        if isfield(datamatrix, 'valdata')
            datamatrix.valdata(a==1)=NaN;
        end
        for i=1:size(datamatrix.moddata,3)
            clear tmp;
            tmp=datamatrix.moddata(:,:,i,:,:);
            tmp(a==1)=NaN;
            datamatrix.moddata(:,:,i,:,:)=tmp;
        end
        if isfield(datamatrix, 'constrain')
            for i=1:size(datamatrix.constrain,3)
                clear tmp;
                tmp=datamatrix.constrain(:,:,i,:,:);
                tmp(a==1)=NaN;
                datamatrix.constrain(:,:,i,:,:)=tmp;
            end
        end
        
        
        % get domain lon/lat:  
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        file=[extdir '/aggregated_LTUR_2013011000.nc'];
        ncid = netcdf.open(file,'NC_NOWRITE');
        varid_lon = netcdf.inqVarID(ncid,'lon_1');
        varid_lat = netcdf.inqVarID(ncid,'lat_1');
        lat  = netcdf.getVar(ncid,varid_lat);
        lon  = netcdf.getVar(ncid,varid_lon);
        lon(lon>180)=lon(lon>180)-360;
        netcdf.close(ncid);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        
        %--------------------
        display('Redefine datamatrix according C. Frei regions division of Switzerland');
        %--------------------
        if avg_fields==1
            unify_regions=[3 5];    % which regions to unify
            [datamatrix_new] = Frei_regions(datamatrix,lat,lon,vars,unify_regions); %averaging the fields over the regions
        else
            datamatrix_new=datamatrix;
            %convert rain field (if exists) to probability maps (for different thresholds and radiuses)
        end
        
        
        %{ 
        % this option is problematic because every fieldshas different size
        clear datamatrix
        for i=1:length(vars_2d)
            datamatrix_tmp=gpts_series(datamatrix_new,vars,vars_2d{i});
            datamatrix.obsdata(i,:,:)=datamatrix_tmp.obsdata(1,:,:);
            datamatrix.refdata(i,:,:)=datamatrix_tmp.refdata(1,:,:);
            datamatrix.moddata(i,:,:,:)=datamatrix_tmp.moddata(1,:,:,:);
            if isfield(datamatrix_tmp, 'valdata')
                datamatrix.valdata(i,:,:)=datamatrix_tmp.valdata(1,:,:);
            end
            if isfield(datamatrix_tmp, 'constrain')
                datamatrix.constrain(i,:,:,:)=datamatrix_tmp.constrain(1,:,:,:);
            end
        end
        %}
        clear datamatrix;
        for i=1:length(vars_2d)
            for d=1:size(datamatrix_new.obsdata,2)
                tmp=datamatrix_new.obsdata(i,d,1,:,:); datamatrix.obsdata(i,d,:)=tmp(:);
                tmp=datamatrix_new.refdata(i,d,1,:,:); datamatrix.refdata(i,d,:)=tmp(:);
                for m=1:size(datamatrix_new.moddata,3)
                    tmp=datamatrix_new.moddata(i,d,m,:,:); datamatrix.moddata(i,d,:,m)=tmp(:);
                end
                if isfield(datamatrix_new, 'valdata')
                    tmp=datamatrix_new.valdata(i,d,1,:,:); datamatrix.valdata(i,d,:)=tmp(:);
                end
                if isfield(datamatrix_new, 'constrain')
                    for m=1:size(datamatrix_new.constrain,3)
                        tmp=datamatrix_new.constrain(i,d,m,:,:); datamatrix.constrain(i,d,:,m)=tmp(:);
                    end
                end
            end
        end
       
        
        % itsik, instead of the following, please write a function which in
        % case of NAN at some g.p (1D) in obs for all the fields and days,
        % set [] for obs and the models.
        datamatrix_backup=datamatrix;  
        datamatrix_new_backup=datamatrix_new; 
        % fields_all=1; % if 'fields all' equal '1' all fields must be avliable 
        fields_all=0; % if 'fields all' equal '0' only one field or above is needed to be avliable no need to all fields to be avaliable
        size(datamatrix_new.obsdata)
    display('STAGE BEFORE  remove_gp(datamatrix_new,fields_all) command')
        [small_datamatrix,grid_datamatrix,calmo_matrix_2D_size]=remove_gp(datamatrix_new,fields_all);
        display('STAGE AFTER  remove_gp(datamatrix_new,fields_all) command')
           display('STAGE OF save grid_datamatrix.mat stage and calmo_matrix_2D_size.mat STAGE')
        save([tmp_str '/grid_datamatrix.mat'],'grid_datamatrix','-v7.3');
        save([tmp_str '/calmo_matrix_2D_size.mat'],'calmo_matrix_2D_size','-v7.3');
        %{
        small_datamatrix_backup=small_datamatrix;
        clear datamatrix
        small_datamatrix_org=small_datamatrix; % with all fields inclunding  SunShine Duration (or maybe Rel SunShine Duration)
        clear small_datamatrix;
        small_datamatrix.obsdata(1:5,:,:)=small_datamatrix_org.obsdata(1:5,:,:);
        small_datamatrix.obsdata(6,:,:)=small_datamatrix_org.obsdata(7,:,:);
        small_datamatrix.refdata(1:5,:,:)=small_datamatrix_org.refdata(1:5,:,:);
        small_datamatrix.refdata(6,:,:)=small_datamatrix_org.refdata(7,:,:);
        small_datamatrix.moddata(1:5,:,:,:)=small_datamatrix_org.moddata(1:5,:,:,:);
        small_datamatrix.moddata(6,:,:,:)=small_datamatrix_org.moddata(7,:,:,:);
        vars_org=vars;
        clear vars;
        for ij=1:5
            vars{ij}=vars_org{ij};
        end
        vars{6}=vars_org{7};
            vars{7}=vars_org{8};
      vars_2d_org=vars_2d;
            clear vars_2d;
        for ij=1:5
            vars_2d{ij}=vars_2d_org{ij};
        end
        vars_2d{6}=vars_2d_org{7};
        %}
        clear datamatrix
        datamatrix=small_datamatrix; 
        size(datamatrix.obsdata)
        
        %save datamatrix.mat datamatrix -v7.3
        display('save datamatrix.mat stage')
        moddata=datamatrix.moddata;
       save([tmp_str '/datamatrix.mat'],'-struct','datamatrix');
      save([tmp_str '/moddata.mat'],'moddata','-v7.3');
      
%save([tmp_str '/datamatrix.mat'],'datamatrix');

    end
    
else
    load('small_datamatrix_backup.mat')
    datamatrix=small_datamatrix_backup;
end
    
    
    
    if ~isempty(strfind([vars{:}],'sound'))
          display('STAGE OF grps_series for sound field(s)')
        datamatrix_so=gpts_series(datamatrix_s,vars,'sound');
        
        %%% Assign NaN in Sonde fields that have less than ml observations per month or period. The Assigment is for all days in the specific month and reigons for that specific month and fields. 
        datatemp=del_bad_sounding(datamatrix_so,ml,sims_reg,sims_inter,sims_con,simval,vars_sound,date_min,date_max);
        clear datamatrix_so
        datamatrix_so=datatemp;
  display('STAGE OF datamatrix_so.mat stage')
        save([tmp_str '/datamatrix_so.mat'],'-struct','datamatrix_so');
        moddata_s=datamatrix_s.moddata;
        save([tmp_str '/moddata_s.mat'],'moddata_s','-v7.3');
 
 %         save([tmp_str '/datamatrix_so.mat'],'datamatrix_so');
        clear datatemp
    end
    
   %} 
    datamatrix=load([tmp_str '/datamatrix.mat']);
     datamatrix_so=load([tmp_str '/datamatrix_so.mat']);
 display('STAGE OF BEFORE NEELING_E_WITOUT_INTERACTION FOR DATAMATRIX')              
metamodel=neelin_e_without_interaction(parameters,datamatrix,vars_2d);
 display('STAGE OF AFTER NEELING_E_WITOUT_INTERACTION FOR DATAMATRIX and before saving to metamodel.mat')      
%save([tmp_str '/metamodel.mat'],'-struct','metamodel');
save([tmp_str '/metamodel.mat'],'metamodel','-v7.3');
%  save([tmp_str '/metamodel.mat'],'metamodel');
if ~isempty(strfind([vars{:}],'sound'))
        metamodel_so=neelin_e_without_interaction(parameters,datamatrix_so,vars_sound); % structure which contains the fitted metamodel parameters for 18 parmeters including T850,T700mb,T500mb,
        % RH850mb, RH700mb, RH500mb , U850mb, U700mb, U500mb , V850mb, V700mb and V500mb.
         % save([tmp_str '/metamodel_so.mat'],'-struct','metamodel_so');
         save([tmp_str '/metamodel_so.mat'],'metamodel_so','-v7.3');
end
       
    return
    
    
    
    
    
    
    
    
    
    avg_T=1
    %%%%%%%%%%%%%%%%%%%%%% SAVE Matrices %%%%%%%%%%%%%%%%%%%%%%%%%%
	display('saving matrices');
    if ~isempty(strfind([vars{:}],'pr')) || ~isempty(strfind([vars{:}],'t2m_avg')) || ~isempty(strfind([vars{:}],'t2m_max')) || ~isempty(strfind([vars{:}],'t2m_min'))...
            ||~isempty(strfind([vars{:}],'Td2m')) || ~isempty(strfind([vars{:}],'td2m_max')) || ~isempty(strfind([vars{:}],'td2m_min')) || ~isempty(strfind([vars{:}],'sunshine'))
        clear tmptmp;
        tmptmp=datamatrix.moddata;
        save([tmp_str '/moddata.mat'],'tmptmp','-v7.3')
        save([tmp_str '/datamatrix.mat'],'-struct','datamatrix');
        
        if avg_T==0
            save([tmp_str '/datamatrix_pr.mat'],'-struct','datamatrix_pr');
            save([tmp_str '/datamatrix_tmax.mat'],'-struct','datamatrix_tmax');
            save([tmp_str '/datamatrix_tmin.mat'],'-struct','datamatrix_tmin');
        else
            save([tmp_str '/datamatrix_new.mat'],'-struct','datamatrix_new');
        end
    end
        
    if ~isempty(strfind([vars{:}],'sound'))
        clear tmptmp;
        tmptmp=datamatrix_s.moddata;
        save([tmp_str '/moddata_s.mat'],'tmptmp','-v7.3')
        save([tmp_str '/datamatrix_s.mat'],'-struct','datamatrix_s');
        save([tmp_str '/datamatrix_so.mat'],'-struct','datamatrix_so'); 
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    
 %{   
    % FIT META-MODELS :
    if avg_T==0
        if ~isempty(strfind([vars{:}],'t2m_max'))
            metamodel_tmax=neelin_e_without_interaction(parameters,datamatrix_tmax,{'t2m_max'}); % structure which contains the fitted metamodel parameters
            save([tmp_str '/metamodel_tmax.mat'],'-struct','metamodel_tmax');
        end
        if ~isempty(strfind([vars{:}],'t2m_min'))
            metamodel_tmin=neelin_e_without_interaction(parameters,datamatrix_tmin,{'t2m_min'}); % structure which contains the fitted metamodel parameters
            save([tmp_str '/metamodel_tmin.mat'],'-struct','metamodel_tmin');
        end
        if ~isempty(strfind([vars{:}],'pr'))
            metamodel_pr=neelin_e_without_interaction(parameters,datamatrix_pr,{'pr'}); % structure which contains the fitted metamodel parameters
            save([tmp_str '/metamodel_pr.mat'],'-struct','metamodel_pr');
        end
    else
        metamodel_new=neelin_e_without_interaction(parameters,datamatrix_new,vars_2d); % structure which contains the fitted metamodel parameters
        save([tmp_str '/metamodel_new.mat'],'-struct','metamodel_new');
    end
%}   
 
if ~isempty(strfind([vars{:}],'sound'))
        metamodel_so=neelin_e_without_interaction(parameters,datamatrix_so,vars_sound); % structure which contains the fitted metamodel parameters for 18 parmeters including T850,T700mb,T500mb,
        % RH850mb, RH700mb, RH500mb , U850mb, U700mb, U500mb , V850mb, V700mb and V500mb.
        save([tmp_str '/metamodel_so.mat'],'-struct','metamodel_so');
end
        
