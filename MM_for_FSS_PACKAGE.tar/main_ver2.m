function main_ver2()

% NAME
%   main
% PURPOSE
%   main program of the CALMO parameters tuning method
% NOTE
%   Set main definitions at namelist.m file !
% RUN
%   from Bash: "matlab -nodesktop -nosplash -r main"
%   from Matlab: F5 inside main.m
% INPUT
%   -
% OUTPUT
%   calibration results saved in .mat format
% AUTHORS
%   Pavel Khain (pavelkh_il@yahoo.com)
%   Itsik Carmona (carmonai@ims.gov.il)
%   Originally: Omar Bellprat (omar.belldate_minprat@gmail.com)

clear all;
close all; clc; format long;

%%%%%%%%%%%%% DETERMINES THE NUMBER OF STAGES THAT THE PROCESS WILL RUN 
%stage=1 % if stage equal 1 run only meta model
%stage=2 % if stage equal 2 run meta model and after that the palnes stage
%stage=3 % if stage equal 3 run meta model and after that the palens stage and after that the interaction stage
stage=11 % if stage equal 6 run only the meta model stage
%stage=22 % if stage equal 4 run only planes stage but don't run the meta model stage
%stage=33 % if stage equal 5 run the planes stage and after that the interation stage but don't run the meta model stage
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% set calibration period and devide it to sub-periods to save MATLAB memory:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


[period_len maindir simuldir obsdir extdir vars vars_2d avg_fields vars_sound sims_opt ml score w_user lhacc iterations_num best_percent date_min date_max]=namelist();

date_diff=datenum(date_max)-datenum(date_min);
if date_diff<10
    display('Unreasonably small period');
    stop;
else
    period_last=floor(date_diff/period_len);
    for p=1:period_last-1
        date_min_arr{p}=datestr(datenum(date_min)+(p-1)*period_len,'dd-mmm-yyyy');
        date_max_arr{p}=datestr(datenum(date_min)+p*period_len-1,'dd-mmm-yyyy');
    end
    date_min_arr{period_last}=datestr(datenum(date_min)+(period_last-1)*period_len,'dd-mmm-yyyy');
    date_max_arr{period_last}=date_max;
end
if(stage<=3 || stage==11)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % STAGE 1: ReadData and fit the MetaModel
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %ABCD=[2:4,6,8,10,12:14,16:18,20:22,24:26,28:30,32:34,36];
    %ABCD=[4,6,8,10,12:14,16:18,20:22,24:26,28:30,32:34,36];
    %for mmm=ABCD
    for mmm=1:length(date_min_arr)
        mmm
        date_min=date_min_arr{mmm};
        date_max=date_max_arr{mmm};
        ReadData_and_MetaModel(date_min,date_max)
    end
    
    %stop
elseif(stage~=11)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % STAGE 2: Post-Processing: The plane stage and the interations stage
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if(stage==22)
        stage2=2;
    end
      if(stage==33)
        stage2=3;
    end
    PostProc_ver2(stage2,date_min_arr,ABCD)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    display('Calibration performed successfully');
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end