function [mat_new,mat_new2]=binary_domain2(mat,mat2,grid_datamatrix,th,nstep,calmo_matrix_2D_size)
% this function read matrix varibale naemd 'mat' and the thershold 'th' . in every matrix cell where the value is above or equal 'th' then it will return '1' otherwist
% Matrix 'mat' must be build on only 1D diminsion , 'grid_datamatrix' is a 2D
% diminsonal matrix with the exis grid points (their value are 1 if the
% exist
% The first dimension in the 'gird_datamatrix' is the longitude (the first line is the most east point and the last line is the west
% The second dimension in the 'grid_datamatrix' is the latitude (the first coulmn is the most south point and the last coulmn is the north point) 
% calmo_matrix_2D_size is 2D size of all CALMO MATRIXs that are in 2D DOMAIN

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%% 1.)THE STAGE or STEP of 'mat_new' binary calcuation(s)
%nstep=2; % number of steps close grid points for interpolation

medium_mat=NaN(calmo_matrix_2D_size(1),calmo_matrix_2D_size(2)); 
medium_mat2=NaN(calmo_matrix_2D_size(1),calmo_matrix_2D_size(2));
% the medium stage of 'mat' before last stage the new stage;
for ii=1:length(grid_datamatrix)
    medium_mat(grid_datamatrix(ii,1),grid_datamatrix(ii,2))=mat(ii);
    medium_mat2(grid_datamatrix(ii,1),grid_datamatrix(ii,2))=mat2(ii);
end
mat_new2=medium_mat*0; % This is in oredr to defined the number of dimensions for the new matrix 'mat new' and also to reset mat_new matrix
mat_new22=medium_mat2*0;
mat_new2(medium_mat>=th)=1;
mat_new22(medium_mat2>=th)=1;
mat_new3=NaN(calmo_matrix_2D_size(1),calmo_matrix_2D_size(2)); 
mat_new32=NaN(calmo_matrix_2D_size(1),calmo_matrix_2D_size(2)); 
XX=[];
ksuc=0;
for iii=(nstep+1):(size(mat_new3,2)-nstep)
 %  iii  
    for jjj=(nstep+1):(size(mat_new3,1)-nstep)
        %  Mtemp=[];
          Mtemp=mat_new2((jjj-nstep):(jjj+nstep),(iii-nstep):(iii+nstep));
          Mtemp2=mat_new22((jjj-nstep):(jjj+nstep),(iii-nstep):(iii+nstep));
          kk=[];
          kk=find(isnan(Mtemp(:)) | isnan(Mtemp2(:)));
          if(length(kk)>0.9)
              Mtemp(kk)=NaN;
              Mtemp2(kk)=NaN;
          end
          if(sum(~isnan(Mtemp(:)))>=ceil(0.25*((2*nstep+1)^2)));
            mat_new3(jjj,iii)=nanmean(Mtemp(:));
            mat_new32(jjj,iii)=nanmean(Mtemp2(:));
          end
           
    end
end
mat_new=NaN(length(grid_datamatrix),1);
mat_new2=NaN(length(grid_datamatrix),1);
for i=1:length(grid_datamatrix)
    mat_new(i)=mat_new3(grid_datamatrix(i,1),grid_datamatrix(i,2));
    mat_new2(i)=mat_new32(grid_datamatrix(i,1),grid_datamatrix(i,2));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% 2. THE FIGURE STAGE or STEP%%%
%Kdims=ndims(mat_new); % number of diminesion for matrix 'mat_new');
%{
for day=1:size(mat_new,1)
    day
    figure
    lat3=0:((size(mat_new,3))+1);
    lon3=0:((size(mat_new,2)+1)/(size(mat_new,3)+1)):(size(mat_new,2)+1);
    plot(lon3,lat3,'-')
    yinverse=size(mat_new,3);
    for y=1:size(mat_new,3)
        for x=1:size(mat_new,2)
            if(mat_new(day,x,yinverse)==0)
                Atext='.' ;
                text(x,y,Atext,'Color','b');
            end
            Atext=' ';
            if(mat_new(day,x,yinverse)==1)
                Atext='.' ;
                text(x,y,Atext,'Color','r');
            end
            if(isnan(mat_new(day,x,yinverse)))
                Atext='.';
                 text(x,y,Atext,'Color','k');
            end
           
        end
        yinverse=yinverse-1;
    end
    title(['Bin map, rain >=',num2str(th),'[mm/day] at day ',num2str(day),' blue=0 reg=1 & black=NaN']); grid on
    ylabel('index of lat from south to north (down to up)')
    xlabel('indext of lon from right to left (west to east)')
    Aprint=['Binary_map_of_the_the_subject_matrix_at_day_',num2str(day),'.png'];
    print(Aprint,'-dpng')
    close
end
%}