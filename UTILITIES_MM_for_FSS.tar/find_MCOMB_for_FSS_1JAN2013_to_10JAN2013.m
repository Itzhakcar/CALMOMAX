Mcomb=[];
ncomb=size(pqn,1)
Mcomb=[];
for i=1:ncomb
    display(['processing combination ' num2str(i) ' of ' num2str(ncomb)]);
	xgrid=linspace(range{pqn(i,1)}(1),range{pqn(i,1)}(2),acc);
	ygrid=linspace(range{pqn(i,2)}(1),range{pqn(i,2)}(2),acc);
  
	[X Y]=meshgrid(xgrid,ygrid);
    xstarp=[];
	xstarp=repmat(refp,[acc^2,1]);
	xstarp(:,pqn(i,1))=X(:);
	xstarp(:,pqn(i,2))=Y(:);
    VV=[];
    for ii=1:100
        Vtemp=[];
        Vtemp=load(['results/01-Jan-2013/fss_score_from_planes_',num2str(i),'_',num2str(ii),'.txt']);
        VV=[VV;Vtemp];
    end
    VVmax=[];
    imax=[];
    [VVmax,imax]=max(VV);
    Mcomb=[Mcomb;pqn(i,:),xstarp(imax,pqn(i,1:2)),VVmax];
end
save(['results/01-Jan-2013/Mcomb.mat'],'Mcomb')
    