clear all
close all
Myearday=[31,28,31,30,31,30,31,31,30,31,30,31];
Maccuday=0;
for i=1:11
    Maccuday=[Maccuday,sum(Myearday(1:i))];
end
[maindir simuldir obsdir extdir vars vars_2d avg_fields vars_sound sims_opt ml score w_user lhacc iterations_num best_percent date_min date_max]=namelist();
date_diff=datenum(date_max)-datenum(date_min);
period_len=10;
if date_diff<10
    display('Unreasonably small period');
    stop;
else
    period_last=floor(date_diff/period_len);
    for p=1:period_last-1
        date_min_arr{p}=datestr(datenum(date_min)+(p-1)*period_len,'dd-mmm-yyyy');
        date_max_arr{p}=datestr(datenum(date_min)+p*period_len-1,'dd-mmm-yyyy');
    end
    date_min_arr{period_last}=datestr(datenum(date_min)+(period_last-1)*period_len,'dd-mmm-yyyy');
    date_max_arr{period_last}=date_max;
end
Mdata=[];
for j=1:length(date_min_arr)
    if(j~=9) % data from 22MAR2013-31MAR2013 are not aviliable
        date_str=date_min_arr{j}
        datamatrix=load([date_str,'/datamatrix.mat']);
        for dayn=1:size(datamatrix.refdata,2)
            VV=[];
            for ifd=1:size(datamatrix.refdata,1)
                KKK=[];
                KKK=find(~isnan(squeeze(datamatrix.obsdata(ifd,dayn,:))) & ~isnan(squeeze(datamatrix.refdata(ifd,dayn,:))));
                if(length(KKK)>=1)
                    VV=[VV,size(datamatrix.obsdata,3),length(KKK),mean(squeeze(datamatrix.obsdata(ifd,dayn,KKK)))];
                    VV=[VV,mean(squeeze(datamatrix.refdata(ifd,dayn,KKK)))];
                else
                    VV=[VV,-999.9,-999.9,-999.9,-999.9];
                end
                for isim=1:size(datamatrix.moddata,4)
                    KKK=[];
                    KKK=find(~isnan(squeeze(datamatrix.obsdata(ifd,dayn,:))) & ~isnan(squeeze(datamatrix.moddata(ifd,dayn,:,isim))));
                    if(length(KKK)>0.999)
                       % VV=[VV,length(KKK),mean(squeeze(datamatrix.obsdata(ifd,dayn,KKK)))];
                        VV=[VV,mean(squeeze(datamatrix.moddata(ifd,dayn,KKK,isim)))];
                    else
                        VV=[VV,-999.9,];
                    end
                end
            end
            dayinyear=(datenum(date_str)-datenum('01-Jan-2013')+dayn);
            for ii=1:11
                Kmonth=1;
                if(dayinyear>Maccuday(ii) && dayinyear<=Maccuday(ii+1))
                    Kmonth=ii+1;
                end
                daymonth=dayinyear-Maccuday(Kmonth);
            end
            Mdata=[Mdata;2013,Kmonth,daymonth,VV];
        end
    end
end
save All_simulation_and_OBSERVATION_DATA_of_DAILY_MEAN_FIELDS_in_2013_for_COSMO1km.txt Mdata -ascii
nMdata=size(Mdata,1);
Mave=zeros(size(datamatrix.refdata,1),(2+size(datamatrix.moddata,2)));
nsum=zeros(size(datamatrix.refdata,1),(2+size(datamatrix.moddata,2)));
kkk=0;
for ifd=1:size(datamatrix.refdata,1)
    for isim=1:size(Mave,2)
        for iday=1:nMdata
            if(Mdata(iday,(5+(ifd-1)*14))>=1)
                if(Mdata(iday,(5+(ifd-1)*14))<=570)
                   stopstop 
                end
                Mave(ifd,isim)=Mave(ifd,isim)+Mdata(iday,(5+(ifd-1)*14))*Mdata(iday,(5+isim+(ifd-1)*14));
          %      whos nsum
          %      ifd
                nsum(ifd,isim)=nsum(ifd,isim)+Mdata(iday,(5+(ifd-1)*14));
            end
        end
        ifd
        isim
        Mave(ifd,isim)
        Mave(ifd,isim)=Mave(ifd,isim)/nsum(ifd,isim);
    end
end
save Mean_2013_All_simulation_and_OBSERVATION_DATA_of_DAILY_MEAN_FIELDS_in_2013_for_COSMO1km.txt Mave -ascii            
            
            

