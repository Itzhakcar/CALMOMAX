%{
clear all
close all
datamatrix=load('02-Mar-2013/datamatrix.mat');
for day=1:size(datamatrix.refdata,2)
    figure
    %display('BEFORE')
    KKK=find(~isnan(datamatrix.obsdata(5,day,:)) & ~isnan(datamatrix.refdata(5,day,:)));
    %display('AFTER')
    if(length(KKK)>=1)
        % scatter(datamatrix.refdata(6,day,:),datamatrix.obsdata(6,day,:));grid on
        dscatter(squeeze(datamatrix.refdata(5,day,KKK)),squeeze(datamatrix.obsdata(5,day,KKK)));
        colorbar
        ylabel('Daily main Tdew Observation [c]')
        xlabel('Daily main Tdew DEF Simulation [c]')
        dayw=day+1;
        daychar=num2str(dayw);
        if(dayw<10)
            daychar=['0',num2str(dayw)];
        end
        title(['All DATA of TDew [c]: DEF simulation Vs Obs on ',daychar,'/03/2013'])
        XY=[];
        XY=[squeeze(datamatrix.refdata(5,day,:)),squeeze(datamatrix.obsdata(5,day,:))];
        XYrealnumbers=[];
        KK=find(~isnan(XY(:,1)) & ~isnan(XY(:,2)));
        XYrealnumbers=XY(KK,:);
        polycoef=polyfit(XYrealnumbers(:,1),XYrealnumbers(:,2),1);
        Xplot=[];
        Yplot=[];
        [Xplot,k]=sort(XYrealnumbers(:,1));
        Yplot=Xplot*polycoef(1)+polycoef(2);
        Rcoef=corrcoef(XYrealnumbers(:,1),XYrealnumbers(:,2))
        CORRELATION=num2str(Rcoef(2,1));
        if(str2num(CORRELATION)>=0.5)
            hold on
            plot(Xplot,Yplot,'r-','LineWidth',1)
            plot(Xplot,Yplot,'r-','LineWidth',1)
            SLOPE=num2str(polycoef(1));
            INTERCEPT=num2str(polycoef(2));
            %text(10,60,['y=',SLOPE,'*x+',INTERCEPT],'FontSize',15,'Color',[0.9 0.05 0.1])
            %text(10,50,['R=',CORRELATION],'FontSize',15,'Color',[0.9 0.05 0.1])
            legend('scatter plot',['y=',SLOPE,'*x+',INTERCEPT],['R=',CORRELATION],'Location','northwest')
        else
            legend(['scatter plot R=',CORRELATION],'Location','northwest')
        end
        print(['All_Daily_Tdew_main_Obs_Vs_DEF_on_',daychar,'MAR2013.png'],'-dpng')
        close
%{
        %%% only data between 0-100
        figure
        XY=[];
        XY=[squeeze(datamatrix.refdata(6,day,:)),squeeze(datamatrix.obsdata(6,day,:))];
        XYrealnumbers=[];
        KK=find((XY(:,1)>=0 & XY(:,1)<=100) & (XY(:,2)>=0 & XY(:,2)<=100));
        XYrealnumbers=XY(KK,:);
        %scatter(XYrealnumbers(:,1),XYrealnumbers(:,2));grid on
        dscatter(XYrealnumbers(:,1),XYrealnumbers(:,2))
        ylabel('SunDuration Observation [%]')
        xlabel('SunDuration Default Simulation [%]')
        daychar=num2str(day);
        if(day<10)
            daychar=['0',num2str(day)];
        end
        title(['FIXED DATA of SunDuration: DEF simulation Vs Obs on ',daychar,'/01/2013'])
        polycoef=polyfit(XYrealnumbers(:,1),XYrealnumbers(:,2),1);
        Xplot=[];
        Yplot=[];
        [Xplot,k]=sort(XYrealnumbers(:,1));
        Yplot=Xplot*polycoef(1)+polycoef(2);
        hold on
        Rcoef=corrcoef(XYrealnumbers(:,1),XYrealnumbers(:,2))
        CORRELATION=num2str(Rcoef(2,1));
        if(str2num(CORRELATION)>=0.5)
            hold on
            plot(Xplot,Yplot,'r-','LineWidth',1)
            plot(Xplot,Yplot,'r-','LineWidth',1)
            plot(Xplot,Yplot,'r-','LineWidth',1)
            SLOPE=num2str(polycoef(1));
            INTERCEPT=num2str(polycoef(2));
            %text(10,60,['y=',SLOPE,'*x+',INTERCEPT],'FontSize',15,'Color',[0.9 0.05 0.1])
            %text(10,50,['R=',CORRELATION],'FontSize',15,'Color',[0.9 0.05 0.1])
            nexpeled=length(find(~isnan(XY(:,1)) & ~isnan(XY(:,1))))-size(XYrealnumbers,1);
            legend('scatter plot',['y=',SLOPE,'*x+',INTERCEPT],['R=',CORRELATION],[num2str(nexpeled),' omitted bad data'])
        else
            legend(['scatter plot R=',CORRELATION])
        end
        %text(10,60,['y=',SLOPE,'*x+',INTERCEPT],'FontSize',15,'Color',[0.9 0.05 0.1])
        %text(10,50,['R=',CORRELATION],'FontSize',15,'Color',[0.9 0.05 0.1])
        print(['FIXED_DATA_of_SUNDUR_Obs_Vs_DEF_on_',daychar,'JAN2013.png'],'-dpng')
        close
%}
    end
end
XX=[];
YY=[];
for day=1:size(datamatrix.refdata,2)
    KKK=find(~isnan(datamatrix.obsdata(5,day,:)) & ~isnan(datamatrix.refdata(5,day,:)));
    XX=[XX;squeeze(datamatrix.refdata(5,day,KKK))];
    YY=[YY;squeeze(datamatrix.obsdata(5,day,KKK))];
end
figure
%display('BEFORE')
%display('AFTER')
if(length(XX)>=1)
    % scatter(datamatrix.refdata(6,day,:),datamatrix.obsdata(6,day,:));grid on
    dscatter(XX,YY);
    colorbar
    ylabel('Daily main Tdew Observation [c]')
    xlabel('Daily main Tdew DEF Simulation [c]')
    dayw=day+1;
    daychar=num2str(dayw);
    if(dayw<10)
        daychar=['0',num2str(dayw)];
    end
    title(['All DATA of TDew [c]: DEF sim Vs Obs for 2/3/2013-11/3/2013'])
    XY=[];
    XY=[XX,YY];
    XYrealnumbers=[];
    KK=find(~isnan(XY(:,1)) & ~isnan(XY(:,2)));
    XYrealnumbers=XY(KK,:);
    polycoef=polyfit(XYrealnumbers(:,1),XYrealnumbers(:,2),1);
    Xplot=[];
    Yplot=[];
    [Xplot,k]=sort(XYrealnumbers(:,1));
    Yplot=Xplot*polycoef(1)+polycoef(2);
    Rcoef=corrcoef(XYrealnumbers(:,1),XYrealnumbers(:,2))
    CORRELATION=num2str(Rcoef(2,1));
    if(str2num(CORRELATION)>=0.5)
        hold on
        plot(Xplot,Yplot,'r-','LineWidth',1)
        plot(Xplot,Yplot,'r-','LineWidth',1)
        SLOPE=num2str(polycoef(1));
        INTERCEPT=num2str(polycoef(2));
        %text(10,60,['y=',SLOPE,'*x+',INTERCEPT],'FontSize',15,'Color',[0.9 0.05 0.1])
        %text(10,50,['R=',CORRELATION],'FontSize',15,'Color',[0.9 0.05 0.1])
        legend('scatter plot',['y=',SLOPE,'*x+',INTERCEPT],['R=',CORRELATION],'Location','southwest')
    else
        legend(['scatter plot R=',CORRELATION],'Location','northwest')
    end
    print(['All_Daily_Tdew_main_Obs_Vs_DEF_for_all_days_in_period_2MAR2013_to_11MAR2013.png'],'-dpng')
    close
    %{
        %%% only data between 0-100
        figure
        XY=[];
        XY=[squeeze(datamatrix.refdata(6,day,:)),squeeze(datamatrix.obsdata(6,day,:))];
        XYrealnumbers=[];
        KK=find((XY(:,1)>=0 & XY(:,1)<=100) & (XY(:,2)>=0 & XY(:,2)<=100));
        XYrealnumbers=XY(KK,:);
        %scatter(XYrealnumbers(:,1),XYrealnumbers(:,2));grid on
        dscatter(XYrealnumbers(:,1),XYrealnumbers(:,2))
        ylabel('SunDuration Observation [%]')
        xlabel('SunDuration Default Simulation [%]')
        daychar=num2str(day);
        if(day<10)
            daychar=['0',num2str(day)];
        end
        title(['FIXED DATA of SunDuration: DEF simulation Vs Obs on ',daychar,'/01/2013'])
        polycoef=polyfit(XYrealnumbers(:,1),XYrealnumbers(:,2),1);
        Xplot=[];
        Yplot=[];
        [Xplot,k]=sort(XYrealnumbers(:,1));
        Yplot=Xplot*polycoef(1)+polycoef(2);
        hold on
        Rcoef=corrcoef(XYrealnumbers(:,1),XYrealnumbers(:,2))
        CORRELATION=num2str(Rcoef(2,1));
        if(str2num(CORRELATION)>=0.5)
            hold on
            plot(Xplot,Yplot,'r-','LineWidth',1)
            plot(Xplot,Yplot,'r-','LineWidth',1)
            plot(Xplot,Yplot,'r-','LineWidth',1)
            SLOPE=num2str(polycoef(1));
            INTERCEPT=num2str(polycoef(2));
            %text(10,60,['y=',SLOPE,'*x+',INTERCEPT],'FontSize',15,'Color',[0.9 0.05 0.1])
            %text(10,50,['R=',CORRELATION],'FontSize',15,'Color',[0.9 0.05 0.1])
            nexpeled=length(find(~isnan(XY(:,1)) & ~isnan(XY(:,1))))-size(XYrealnumbers,1);
            legend('scatter plot',['y=',SLOPE,'*x+',INTERCEPT],['R=',CORRELATION],[num2str(nexpeled),' omitted bad data'])
        else
            legend(['scatter plot R=',CORRELATION])
        end
        %text(10,60,['y=',SLOPE,'*x+',INTERCEPT],'FontSize',15,'Color',[0.9 0.05 0.1])
        %text(10,50,['R=',CORRELATION],'FontSize',15,'Color',[0.9 0.05 0.1])
        print(['FIXED_DATA_of_SUNDUR_Obs_Vs_DEF_on_',daychar,'JAN2013.png'],'-dpng')
        close
    %}
end
%}
clear all
close all
[maindir simuldir obsdir extdir vars vars_2d avg_fields vars_sound sims_opt ml score w_user lhacc iterations_num best_percent date_min date_max]=namelist();
date_diff=datenum(date_max)-datenum(date_min);
period_len=10;
if date_diff<10
    display('Unreasonably small period');
    stop;
else
    period_last=floor(date_diff/period_len);
    for p=1:period_last-1
        date_min_arr{p}=datestr(datenum(date_min)+(p-1)*period_len,'dd-mmm-yyyy');
        date_max_arr{p}=datestr(datenum(date_min)+p*period_len-1,'dd-mmm-yyyy');
    end
    date_min_arr{period_last}=datestr(datenum(date_min)+(period_last-1)*period_len,'dd-mmm-yyyy');
    date_max_arr{period_last}=date_max;
end
XX=[];
YY=[];
for j=1:3:length(date_min_arr)
    if(j~=9) % data from 22MAR2013-31MAR2013 are not aviliable
    date_str=date_min_arr{j}
    datamatrix=load([date_str,'/datamatrix.mat']);
        for day=1:size(datamatrix.refdata,2)
            KKK=find(~isnan(squeeze(datamatrix.obsdata(5,day,:))) & ~isnan(squeeze(datamatrix.refdata(5,day,:))));
            if(length(KKK)>=1)
                XX=[XX;squeeze(datamatrix.refdata(5,day,KKK))];
                YY=[YY;squeeze(datamatrix.obsdata(5,day,KKK))];
            end
        end
    end
end
figure
dscatter(XX,YY) %,'BINS',[20,20]);grid on
ylabel('Daily Tdew2m Observation [c')
xlabel('Daily Tdew2m Default Simulation [c]')
title('Daily Tdew2m: DEF sim Vs Obs for 1/1/2013-26/12/13')
XY=[];
XY=[XX,YY];
XYrealnumbers=[];
KK=find(~isnan(XY(:,1)) & ~isnan(XY(:,2)));
XYrealnumbers=XY(KK,:);
polycoef=polyfit(XYrealnumbers(:,1),XYrealnumbers(:,2),1);
Xplot=[];
Yplot=[];
[Xplot,k]=sort(XYrealnumbers(:,1));
Yplot=Xplot*polycoef(1)+polycoef(2);
Rcoef=corrcoef(XYrealnumbers(:,1),XYrealnumbers(:,2))
CORRELATION=num2str(Rcoef(2,1));
if(str2num(CORRELATION)>=0.5)
    hold on
    plot(Xplot,Yplot,'r-','LineWidth',1)
    plot(Xplot,Yplot,'r-','LineWidth',1)
    SLOPE=num2str(polycoef(1));
    INTERCEPT=num2str(polycoef(2));
    %text(10,60,['y=',SLOPE,'*x+',INTERCEPT],'FontSize',15,'Color',[0.9 0.05 0.1])
    %text(10,50,['R=',CORRELATION],'FontSize',15,'Color',[0.9 0.05 0.1])
    legend(['y=',SLOPE(1:3),'*x+',INTERCEPT(1:3)],['R=',CORRELATION(1:4)],'Location','northwest')
else
    legend(['scatter plot R=',CORRELATION(1:4)],'Location','northwest')
end
colorbar
print('All_TDEW_Obs_Vs_DEF_on_the_for_almost_all_2013_for_1JAN2013_to_26DEC2013.png','-dpng')
close