clear all
close all
extdir='/Research/models/CALMO1km/external_data/';
extfile=[extdir,'aggregated_LTUR_2013011000.nc'];
TDdir='/Research/models/CALMOMAX/DewPoint/';
latcalmo=ncread(extfile,'lat_1');
loncalmo=ncread(extfile,'lon_1');
load([TDdir,'Tdew_lat_of_swiss_DOMIAN.mat']);
load([TDdir,'Tdew_lon_of_swiss_DOMIAN.mat']);
load([TDdir,'sunshine_duration_DOMAIN_SWISS_lat1.mat']);
load([TDdir,'sunshine_duration_DOMAIN_SWISS_lon1.mat']);
load([TDdir,'sunshine.mat']);
load([TDdir,'TDmatrixave.mat']);
load([TDdir,'TDmatrixmax.mat']);
load([TDdir,'TDmatrixmin.mat']);
lat1=lat_of_swiss_DOMIAN;
lon1=lon_of_swiss_DOMIAN;
display('TDave reading stage')
load TDave
display('TDmax reading stage')
load TDmax
display('TDmin reading stage')
load TDmin
Ntest=100; % number of test
iii=1;
BIAS=[];
while iii<=Ntest
    latrand=round((44+3*rand)*100)/100;
    lonrand=round((8+4*rand)*100)/100;
    day=round(rand*365+0.5);
    A=[];
    B=[];
    A=find((lat1(:)<=latrand & lat1(:)>(latrand-0.01)) & (lon1(:)<=lonrand & lon1(:)>(lonrand-0.01)));
    B=find((latcalmo(:)<=latrand & latcalmo(:)>(latrand-0.01)) & (loncalmo(:)<=lonrand & loncalmo(:)>(lonrand-0.01)));
    if(length(A)==1 & length(B)==1 & (day>=1 & day<=365))
        C=[];
        D=[];
        C=squeeze(TDave(:,:,day));
        D=squeeze(TDmatrixave(day,:,:));
        BIAS=[BIAS;C(B),D(A)];
        iii=iii+1
    end
end
