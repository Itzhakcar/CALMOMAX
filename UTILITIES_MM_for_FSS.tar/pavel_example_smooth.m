function main_c3(dat,hh,run_dat,run_hh,file_a,file_b)
close all; fclose('all');

%{
dat ='20171206'
hh ='00'
run_dat ='20171203'
run_hh='12'
file_a='lfff02060000'
file_b='lfff02120000'
%}

c3_bin=0;
if datenum(strcat(dat,hh),'yyyymmddhh')<datenum('2016110100','yyyymmddhh')
    c3_bin=1;
end  

clear global obs_calc_real c3_calc_real ec_calc_real gf_calc_real uk_calc_real ic_calc_real obs_calc_binary c3_calc_binary ec_calc_binary gf_calc_binary uk_calc_binary ic_calc_binary calc_prob calc_prob_obs calc_prob_c3 calc_prob_ec calc_prob_gf calc_prob_uk calc_prob_ic
global obs_calc_real c3_calc_real ec_calc_real gf_calc_real uk_calc_real ic_calc_real obs_calc_binary c3_calc_binary ec_calc_binary gf_calc_binary uk_calc_binary ic_calc_binary calc_prob calc_prob_obs calc_prob_c3 calc_prob_ec calc_prob_gf calc_prob_uk calc_prob_ic
clear global suf_c3 suf_ec latgrid longrid lon_min lat_min xqmod yqmod latgrid_ec longrid_ec lon_ec lat_ec thresholds radiuses verif_mask lon_max lat_max
global suf_c3 suf_ec latgrid longrid lon_min lat_min xqmod yqmod latgrid_ec longrid_ec lon_ec lat_ec thresholds radiuses verif_mask lon_max lat_max
clear global latgrid_gf longrid_gf lon_gf lat_gf latgrid_uk longrid_uk lon_uk lat_uk latgrid_ic longrid_ic lon_ic lat_ic
global latgrid_gf longrid_gf lon_gf lat_gf latgrid_uk longrid_uk lon_uk lat_uk latgrid_ic longrid_ic lon_ic lat_ic glob_grid
clear global maindir workdir; global maindir workdir
%maindir='/Research/models/Output/rain_verif_routine/calc';
%workdir='/Research/models/Output/rain_verif_routine';
maindir='/ims_data/Research/models/Output/verif_case/rain/calc';
workdir='/ims_data/Research/models/Output/verif_case/rain';

fid=fopen('/ims_data/Research/models/Output/verif_case/data.txt','r');
fgets(fid); %dat    %ignored
fgets(fid); %hh     %ignored
testnum=fgets(fid); %test

obs_flag=1; obs_calc_real=1;
c3_flag=1; c3_calc_real=1;
ec_flag=1; ec_calc_real=1;
gf_flag=1; gf_calc_real=1;
uk_flag=1; uk_calc_real=1;
ic_flag=1; ic_calc_real=1;

obs_calc_binary=1;
c3_calc_binary=1;
ec_calc_binary=1;
gf_calc_binary=1;
uk_calc_binary=1;
ic_calc_binary=1;

calc_prob=1;
calc_prob_obs=1;
calc_prob_c3=1;
calc_prob_ec=1;
calc_prob_gf=1;
calc_prob_uk=1;
calc_prob_ic=1;

'main_c3'
[maindir '/output/ob/obs6h_real_' strcat(strcat(dat,hh),'.mat')]
[maindir '/output/ob/obs6h_' strcat(strcat(dat,hh),'.mat')]
strcat(maindir,'/output/c3_',testnum,'/mod6h_c3_real_',strcat(run_dat,run_hh),'_',strcat(dat,hh),'.mat')
strcat(maindir,'/output/c3_',testnum,'/mod6h_c3_',strcat(run_dat,run_hh),'_',strcat(dat,hh),'.mat')
[maindir '/output/ec/mod6h_ec_real_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')]
[maindir '/output/ec/mod6h_ec_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')]
strcat(maindir,'/output/c3_',testnum,'/prob_c3_',strcat(run_dat,run_hh),'_',strcat(dat,hh),'.mat')

if exist([maindir '/output/ob/obs6h_real_' strcat(strcat(dat,hh),'.mat')],'file') obs_calc_real=0; end;
if exist([maindir '/output/ob/obs6h_' strcat(strcat(dat,hh),'.mat')],'file') obs_calc_binary=0; end;
if exist(strcat(maindir,'/output/c3_',testnum,'/mod6h_c3_real_',strcat(run_dat,run_hh),'_',strcat(dat,hh),'.mat'),'file') c3_calc_real=0; end;
if exist(strcat(maindir,'/output/c3_',testnum,'/mod6h_c3_',strcat(run_dat,run_hh),'_',strcat(dat,hh),'.mat'),'file') c3_calc_binary=0; end;
if exist([maindir '/output/ec/mod6h_ec_real_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')],'file') ec_calc_real=0; end;
if exist([maindir '/output/ec/mod6h_ec_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')],'file') ec_calc_binary=0; end;
if exist([maindir '/output/gf/mod6h_gf_real_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')],'file') gf_calc_real=0; end;
if exist([maindir '/output/gf/mod6h_gf_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')],'file') gf_calc_binary=0; end;
if exist([maindir '/output/uk/mod6h_uk_real_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')],'file') uk_calc_real=0; end;
if exist([maindir '/output/uk/mod6h_uk_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')],'file') uk_calc_binary=0; end;
if exist([maindir '/output/ic/mod6h_ic_real_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')],'file') ic_calc_real=0; end;
if exist([maindir '/output/ic/mod6h_ic_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')],'file') ic_calc_binary=0; end;
if exist([maindir '/output/ob/prob_obs_' strcat(strcat(dat,hh),'.mat')],'file') calc_prob_obs=0; end;
if exist(strcat(maindir,'/output/c3_',testnum,'/prob_c3_',strcat(run_dat,run_hh),'_',strcat(dat,hh),'.mat'),'file') calc_prob_c3=0; end;
if exist([maindir '/output/ec/prob_ec_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')],'file') calc_prob_ec=0; end;
if exist([maindir '/output/gf/prob_gf_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')],'file') calc_prob_gf=0; end;
if exist([maindir '/output/uk/prob_uk_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')],'file') calc_prob_uk=0; end;
if exist([maindir '/output/ic/prob_ic_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')],'file') calc_prob_ic=0; end;

%if strcmp(strcat(testnum),'oper') || strcmp(strcat(testnum),'cams') || strcmp(strcat(testnum),'c1winrain') 
%    c3_calc_real=1; c3_calc_binary=1; calc_prob_c3=1;
%end
if calc_prob_obs==0 && calc_prob_c3==0 && calc_prob_ec==0 && calc_prob_gf==0 && calc_prob_uk==0 && calc_prob_ic==0
    calc_prob=0; obs_flag=0; c3_flag=0; ec_flag=0; gf_flag=0; uk_flag=0; ic_flag=0;  
end


suf_c3={'0000','0006','0012','0018','0100','0106','0112','0118','0200','0206','0212','0218','0300','0306'};
suf_ec={'000','006','012','018','024','030','036','042','048','054','060','066','072','078'};

latgrid=26:0.025:36;
longrid=25:0.025:39;
lon_min=find(longrid==34); lon_max=find(longrid==36); 
lat_min=find(latgrid==30); lat_max=find(latgrid==33.4); 
[xqmod,yqmod] = meshgrid(longrid, latgrid);

latgrid_ec=20:0.1:45;
longrid_ec=20:0.1:45;
if datenum(strcat(run_dat,run_hh),'yyyymmddhh')<datenum('2017030812','yyyymmddhh')
    latgrid_ec=20:0.125:45;
    longrid_ec=20:0.125:45;
end
[lon_ec,lat_ec]=meshgrid(longrid_ec,latgrid_ec);

latgrid_gf=10:0.25:60;
longrid_gf=0:0.25:50;
if datenum(strcat(run_dat,run_hh),'yyyymmddhh')<datenum('2016010100','yyyymmddhh')
    latgrid_gf=10:0.5:60;
    longrid_gf=0:0.5:50;    
end
[lon_gf,lat_gf]=meshgrid(longrid_gf,latgrid_gf);

if datenum(strcat(run_dat,run_hh),'yyyymmddhh')<datenum('2018010100','yyyymmddhh')
	latgrid_uk=10:0.55556:60.0004;
	longrid_uk=0:0.83333:50;
else
	latgrid_uk=9.984:0.156:59.904;
	longrid_uk=0.162:0.234:45.09;
end
[lon_uk,lat_uk]=meshgrid(longrid_uk,latgrid_uk);

latgrid_ic=10:0.25:50;
longrid_ic=0:0.25:60;
[lon_ic,lat_ic]=meshgrid(longrid_ic,latgrid_ic);

glob_grid{1}.latgrid=latgrid_ec; glob_grid{1}.longrid=longrid_ec; glob_grid{1}.lon=lon_ec; glob_grid{1}.lat=lat_ec; glob_grid{1}.name='EC'; glob_grid{1}.savename='ec'; glob_grid{1}.calc=ec_calc_real; glob_grid{1}.calcbin=ec_calc_binary;
glob_grid{2}.latgrid=latgrid_gf; glob_grid{2}.longrid=longrid_gf; glob_grid{2}.lon=lon_gf; glob_grid{2}.lat=lat_gf; glob_grid{2}.name='GF'; glob_grid{2}.savename='gf'; glob_grid{2}.calc=gf_calc_real; glob_grid{2}.calcbin=gf_calc_binary;
if datenum(strcat(run_dat,run_hh),'yyyymmddhh')<datenum('2018010100','yyyymmddhh')
	glob_grid{3}.latgrid=latgrid_uk; glob_grid{3}.longrid=longrid_uk; glob_grid{3}.lon=lon_uk; glob_grid{3}.lat=lat_uk; glob_grid{3}.name='BH'; glob_grid{3}.savename='uk'; glob_grid{3}.calc=uk_calc_real; glob_grid{3}.calcbin=uk_calc_binary;
else
	glob_grid{3}.latgrid=latgrid_uk; glob_grid{3}.longrid=longrid_uk; glob_grid{3}.lon=lon_uk; glob_grid{3}.lat=lat_uk; glob_grid{3}.name='UK'; glob_grid{3}.savename='uk'; glob_grid{3}.calc=uk_calc_real; glob_grid{3}.calcbin=uk_calc_binary;
end
glob_grid{4}.latgrid=latgrid_ic; glob_grid{4}.longrid=longrid_ic; glob_grid{4}.lon=lon_ic; glob_grid{4}.lat=lat_ic; glob_grid{4}.name='OH'; glob_grid{4}.savename='ic'; glob_grid{4}.calc=ic_calc_real; glob_grid{4}.calcbin=ic_calc_binary;
if c3_bin==1
    glob_grid{5}.latgrid=latgrid; glob_grid{5}.longrid=longrid; glob_grid{5}.lon=xqmod; glob_grid{5}.lat=yqmod; glob_grid{5}.name='C3'; glob_grid{5}.savename='c3_oper'; glob_grid{5}.calc=c3_calc_real; glob_grid{5}.calcbin=c3_calc_binary;
end

thresholds=[0.01 0.1 0.5 1 2 5 10 20]; % in mm
radiuses=[5 10 20 30 50 70 100]; % in km
verif_mask=within_domain();
verif_mask=zoom_in(verif_mask,lon_min,lon_max,lat_min,lat_max);

display(['processing ' strcat(run_dat,run_hh) '_' strcat(dat,hh)]);

if obs_flag==1
    %%% read RADAR data %%%
    obs6h=func_obs_calc_real(dat,hh);   
    % OBS binary fields %
    obs_binar=func_obs_calc_binar(dat,hh,obs6h); 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
if c3_flag==1
    %%% read COSMO data %%%
    if c3_bin==0
        mod6h_c3=func_c3_calc_real(dat,hh,run_dat,run_hh,file_a,file_b);
    else
        mod6h_c3=func_calc_real(dat,hh,run_dat,run_hh,5);
    end
    if isnan(mod6h_c3) & length(mod6h_c3)==1
        calc_prob_c3=0;
    else
        % C3 binary fields %
        if c3_bin==0
            c3_binar=func_c3_calc_binar(dat,hh,run_dat,run_hh,mod6h_c3); 
        else
            c3_binar=func_calc_binar(dat,hh,run_dat,run_hh,mod6h_c3,5);  
        end
    end
end
if ec_flag==1
    %%% read EC data %%%
    mod6h_ec=func_calc_real(dat,hh,run_dat,run_hh,1);   %1-EC,2-GF,3-UK,4-IC
    if isnan(mod6h_ec) & length(mod6h_ec)==1
        calc_prob_ec=0;
    else
        % EC binary fields %
        ec_binar=func_calc_binar(dat,hh,run_dat,run_hh,mod6h_ec,1);  
    end
end
if gf_flag==1
    %%% read GF data %%%
    mod6h_gf=func_calc_real(dat,hh,run_dat,run_hh,2);   %1-EC,2-GF,3-UK,4-IC
    if isnan(mod6h_gf) & length(mod6h_gf)==1
        calc_prob_gf=0;
    else
        % GF binary fields %
        gf_binar=func_calc_binar(dat,hh,run_dat,run_hh,mod6h_gf,2);  
    end
end
if uk_flag==1
    %%% read UK data %%%
    mod6h_uk=func_calc_real(dat,hh,run_dat,run_hh,3);   %1-EC,2-GF,3-UK,4-IC
    if isnan(mod6h_uk) & length(mod6h_uk)==1
        calc_prob_uk=0;
    else
        % UK binary fields %
        uk_binar=func_calc_binar(dat,hh,run_dat,run_hh,mod6h_uk,3);  
    end
end
if ic_flag==1
    %%% read IC data %%%
    mod6h_ic=func_calc_real(dat,hh,run_dat,run_hh,4);   %1-EC,2-GF,3-UK,4-IC
    if isnan(mod6h_ic) & length(mod6h_ic)==1
        calc_prob_ic=0;
    else
        % IC binary fields %
        ic_binar=func_calc_binar(dat,hh,run_dat,run_hh,mod6h_ic,4);  
    end
end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if calc_prob_obs==0 && calc_prob_c3==0 && calc_prob_ec==0 && calc_prob_gf==0 && calc_prob_uk==0 && calc_prob_ic==0
    calc_prob=0; obs_flag=0; c3_flag=0; ec_flag=0; gf_flag=0; uk_flag=0; ic_flag=0;  
end

if calc_prob==1
    % ------------- neighborhood probabilities ------------------------------
    display(['Calculate neighborhood probabilities for 6h before ' strcat(dat,hh)]);
    for ithreshold=1:length(thresholds)
        display(['threshold=' num2str(thresholds(ithreshold))]);
        for iradius=1:length(radiuses)+1
            if iradius~=(length(radiuses)+1)
                display(['radius=' num2str(radiuses(iradius))]);
                %Latitude: 1 deg = 110.54 km                                        ~100km
                %Longitude: 1 deg = 111.320*cos(32*pi/180) km    ~100km

                radius_latlon=radiuses(iradius)/100;
                radius_gp=round(radius_latlon/0.025)+1;

                clear tmp_prob_obs tmp_prob_c3 tmp_prob_ec tmp_prob_gf tmp_prob_uk tmp_prob_ic area;
                if calc_prob_obs==1 tmp_prob_obs(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=NaN; end;
                if calc_prob_c3==1 tmp_prob_c3(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=NaN; end;
                if calc_prob_ec==1 tmp_prob_ec(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=NaN; end;
                if calc_prob_gf==1 tmp_prob_gf(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=NaN; end;
                if calc_prob_uk==1 tmp_prob_uk(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=NaN; end;
                if calc_prob_ic==1 tmp_prob_ic(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=NaN; end;
                area(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=NaN;
                for i=1:lon_max-lon_min+1
                    for j=1:lat_max-lat_min+1
                        if verif_mask(i,j)==1
                            if calc_prob_obs==1
                                clear tmp;
                                tmp=obs_binar{ithreshold}(max(1,i-radius_gp):min(lon_max-lon_min+1,i+radius_gp),max(1,j-radius_gp):min(lat_max-lat_min+1,j+radius_gp));
                                tmp_prob_obs(i,j)=nansum(tmp(:));
                            end
                            if calc_prob_c3==1
                                clear tmp;
                                tmp=c3_binar{ithreshold}(max(1,i-radius_gp):min(lon_max-lon_min+1,i+radius_gp),max(1,j-radius_gp):min(lat_max-lat_min+1,j+radius_gp));
                                tmp_prob_c3(i,j)=nansum(tmp(:));
                            end
                            if calc_prob_ec==1
                                clear tmp;
                                tmp=ec_binar{ithreshold}(max(1,i-radius_gp):min(lon_max-lon_min+1,i+radius_gp),max(1,j-radius_gp):min(lat_max-lat_min+1,j+radius_gp));
                                tmp_prob_ec(i,j)=nansum(tmp(:));
                            end
                            if calc_prob_gf==1
                                clear tmp;
                                tmp=gf_binar{ithreshold}(max(1,i-radius_gp):min(lon_max-lon_min+1,i+radius_gp),max(1,j-radius_gp):min(lat_max-lat_min+1,j+radius_gp));
                                tmp_prob_gf(i,j)=nansum(tmp(:));
                            end
                            if calc_prob_uk==1
                                clear tmp;
                                tmp=uk_binar{ithreshold}(max(1,i-radius_gp):min(lon_max-lon_min+1,i+radius_gp),max(1,j-radius_gp):min(lat_max-lat_min+1,j+radius_gp));
                                tmp_prob_uk(i,j)=nansum(tmp(:));
                            end
                            if calc_prob_ic==1
                                clear tmp;
                                tmp=ic_binar{ithreshold}(max(1,i-radius_gp):min(lon_max-lon_min+1,i+radius_gp),max(1,j-radius_gp):min(lat_max-lat_min+1,j+radius_gp));
                                tmp_prob_ic(i,j)=nansum(tmp(:));
                            end

                            clear tmp1;
                            tmp1=tmp(~isnan(tmp));
                            area(i,j)=length(tmp1(:));
                        end
                    end
                end
                if calc_prob_obs==1 tmp_prob_obs(area<0.5*(2*radius_gp+1)^2)=NaN; end;
                if calc_prob_c3==1 tmp_prob_c3(area<0.5*(2*radius_gp+1)^2)=NaN; end;
                if calc_prob_ec==1 tmp_prob_ec(area<0.5*(2*radius_gp+1)^2)=NaN; end;
                if calc_prob_gf==1 tmp_prob_gf(area<0.5*(2*radius_gp+1)^2)=NaN; end;
                if calc_prob_uk==1 tmp_prob_uk(area<0.5*(2*radius_gp+1)^2)=NaN; end;
                if calc_prob_ic==1 tmp_prob_ic(area<0.5*(2*radius_gp+1)^2)=NaN; end;
                area(area<0.5*(2*radius_gp+1)^2)=NaN;

                if calc_prob_obs==1 prob_obs{ithreshold,iradius}(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=tmp_prob_obs./area; end;
                if calc_prob_c3==1 prob_c3{ithreshold,iradius}(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=tmp_prob_c3./area; end; 
                if calc_prob_ec==1 prob_ec{ithreshold,iradius}(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=tmp_prob_ec./area; end;
                if calc_prob_gf==1 prob_gf{ithreshold,iradius}(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=tmp_prob_gf./area; end;
                if calc_prob_uk==1 prob_uk{ithreshold,iradius}(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=tmp_prob_uk./area; end;
                if calc_prob_ic==1 prob_ic{ithreshold,iradius}(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=tmp_prob_ic./area; end;
            else    %entire domain
                display('radius=entire domain');
                tmp_obs_sum=0; 
                tmp_c3_sum=0;
                tmp_ec_sum=0;
                tmp_gf_sum=0;
                tmp_uk_sum=0;
                tmp_ic_sum=0;
                area=0;
                for i=1:lon_max-lon_min+1
                    for j=1:lat_max-lat_min+1
                        if verif_mask(i,j)==1
                            if calc_prob_obs==1 tmp_obs_sum=tmp_obs_sum+obs_binar{ithreshold}(i,j); end;
                            if calc_prob_c3==1 tmp_c3_sum=tmp_c3_sum+c3_binar{ithreshold}(i,j); end;
                            if calc_prob_ec==1 tmp_ec_sum=tmp_ec_sum+ec_binar{ithreshold}(i,j); end;
                            if calc_prob_gf==1 tmp_gf_sum=tmp_ec_sum+gf_binar{ithreshold}(i,j); end;
                            if calc_prob_uk==1 tmp_uk_sum=tmp_ec_sum+uk_binar{ithreshold}(i,j); end;
                            if calc_prob_ic==1 tmp_ic_sum=tmp_ec_sum+ic_binar{ithreshold}(i,j); end;
                            area=area+1;
                        end
                    end
                end
                if calc_prob_obs==1 prob_obs{ithreshold,iradius}(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=tmp_obs_sum./area; end;
                if calc_prob_c3==1 prob_c3{ithreshold,iradius}(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=tmp_c3_sum./area; end;
                if calc_prob_ec==1 prob_ec{ithreshold,iradius}(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=tmp_ec_sum./area; end;
                if calc_prob_gf==1 prob_gf{ithreshold,iradius}(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=tmp_gf_sum./area; end;
                if calc_prob_uk==1 prob_uk{ithreshold,iradius}(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=tmp_uk_sum./area; end;
                if calc_prob_ic==1 prob_ic{ithreshold,iradius}(1:lon_max-lon_min+1,1:lat_max-lat_min+1)=tmp_ic_sum./area; end;
            end
        end
    end

    display('Done with calculating probabilities');

	[maindir '/output/ob/prob_obs_' strcat(dat,hh)]
	strcat(maindir,'/output/c3_',testnum,'/prob_c3_',strcat(run_dat,run_hh),'_',strcat(dat,hh))
	[maindir '/output/ec/prob_ec_' strcat(run_dat,run_hh) '_' strcat(dat,hh)]

    if calc_prob_obs==1 save([maindir '/output/ob/prob_obs_' strcat(dat,hh)],'prob_obs'); end;
    if calc_prob_c3==1 save(strcat(maindir,'/output/c3_',testnum,'/prob_c3_',strcat(run_dat,run_hh),'_',strcat(dat,hh)),'prob_c3'); end;
    if calc_prob_ec==1 save([maindir '/output/ec/prob_ec_' strcat(run_dat,run_hh) '_' strcat(dat,hh)],'prob_ec'); end; 
    if calc_prob_gf==1 save([maindir '/output/gf/prob_gf_' strcat(run_dat,run_hh) '_' strcat(dat,hh)],'prob_gf'); end; 
    if calc_prob_uk==1 save([maindir '/output/uk/prob_uk_' strcat(run_dat,run_hh) '_' strcat(dat,hh)],'prob_uk'); end; 
    if calc_prob_ic==1 save([maindir '/output/ic/prob_ic_' strcat(run_dat,run_hh) '_' strcat(dat,hh)],'prob_ic'); end; 
else    
    if calc_prob_obs==1 load([maindir '/output/ob/prob_obs_' strcat(strcat(dat,hh),'.mat')]); end;
    if calc_prob_c3==1 load(strcat(maindir,'/output/c3_',testnum,'/prob_c3_',strcat(run_dat,run_hh),'_',strcat(dat,hh),'.mat')); end;
    if calc_prob_ec==1 load([maindir '/output/ec/prob_ec_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')]); end;
    if calc_prob_gf==1 load([maindir '/output/gf/prob_gf_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')]); end;
    if calc_prob_uk==1 load([maindir '/output/uk/prob_uk_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')]); end;
    if calc_prob_ic==1 load([maindir '/output/ic/prob_ic_' strcat(run_dat,run_hh) '_' strcat(strcat(dat,hh),'.mat')]); end;
end




