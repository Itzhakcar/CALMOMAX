clear all
close all
extdir='/Research/models/CALMO1km/external_data/';
extfile=[extdir,'aggregated_LTUR_2013011000.nc'];
TDdir='/Research/models/CALMOMAX/DewPoint/';
latcalmo=ncread(extfile,'lat_1');
loncalmo=ncread(extfile,'lon_1');
load([TDdir,'Tdew_lat_of_swiss_DOMIAN.mat']);
load([TDdir,'Tdew_lon_of_swiss_DOMIAN.mat']);
load([TDdir,'sunshine_duration_DOMAIN_SWISS_lat1.mat']);
load([TDdir,'sunshine_duration_DOMAIN_SWISS_lon1.mat']);
load([TDdir,'sunshine.mat']);
load([TDdir,'TDmatrixave.mat']);
load([TDdir,'TDmatrixmax.mat']);
load([TDdir,'TDmatrixmin.mat']);
XX=[];
Rmin=2; % the distance to the stations
Ngrid=4; % the number of grid points for nearest number of grid points (POINTSSS) for making interpolation
Rearth=6370;
VV=NaN(size(latcalmo,1),size(loncalmo,2),365);
gridpoint=0;
for i=3:(size(latcalmo,2)-2)
    i
    for j=3:(size(loncalmo,1)-2)
  %      clear KK RR Rsorted isorted
        KK=find((2*pi*Rearth/360*sqrt((cos(latcalmo(j,i)*pi/180)*(lon1(:)-loncalmo(j,i))).^2+(lat1(:)-latcalmo(j,i)).^2))<Rmin);
        % Approx Distance between grid points
        
        if(length(KK)>=Ngrid)
            RR=2*pi*Rearth/360*sqrt((cos(latcalmo(j,i)*pi/180)*(lon1(KK)-loncalmo(j,i))).^2+(lat1(KK)-latcalmo(j,i)).^2);
            [Rsorted,isorted]=sort(RR);
            for day=1:365
                if(sum(isnan(sunshine(day,KK(isorted(1:Ngrid)))))<0.1)
                    VV(j,i,day)=mean(sunshine(day,KK(isorted(1:Ngrid))));
                end
            end
        end
    end
end
sunshinecalmo=VV;
save sunshinecalmo.mat sunshinecalmo -v7.3
lat1=[];
lon1=[];
lat1=lat_of_swiss_DOMIAN;
lon1=lon_of_swiss_DOMIAN;
VVave=NaN(size(latcalmo,1),size(loncalmo,2),365);
VVmax=NaN(size(latcalmo,1),size(loncalmo,2),365);
VVmin=NaN(size(latcalmo,1),size(loncalmo,2),365);
gridpoint=0;
for i=3:(size(latcalmo,2)-2)
    i
    for j=3:(size(loncalmo,1)-2)
  %      clear KK RR Rsorted isorted
        KK=find((2*pi*Rearth/360*sqrt((cos(latcalmo(j,i)*pi/180)*(lon1(:)-loncalmo(j,i))).^2+(lat1(:)-latcalmo(j,i)).^2))<Rmin);
        % Approx Distance between grid points
        
        if(length(KK)>=Ngrid)
            RR=2*pi*Rearth/360*sqrt((cos(latcalmo(j,i)*pi/180)*(lon1(KK)-loncalmo(j,i))).^2+(lat1(KK)-latcalmo(j,i)).^2);
            [Rsorted,isorted]=sort(RR);
            for day=1:365
                if(sum(isnan(TDmatrixave(day,KK(isorted(1:Ngrid)))))<0.1)
                    VVave(j,i,day)=mean(TDmatrixave(day,KK(isorted(1:Ngrid))));
                   
                end
                if(sum(isnan(TDmatrixmax(day,KK(isorted(1:Ngrid)))))<0.1)
                    VVmax(j,i,day)=mean(TDmatrixmax(day,KK(isorted(1:Ngrid))));
                end
                if(sum(isnan(TDmatrixmin(day,KK(isorted(1:Ngrid)))))<0.1)
                    VVmin(j,i,day)=mean(TDmatrixmin(day,KK(isorted(1:Ngrid))));
                end
            end
        end
    end
end
TDave=VVave;
TDmax=VVmax;
TDmin=VVmin;
save TDave.mat TDave -v7.3
save TDmax.mat TDmax -v7.3
save TDmin.mat TDmin -v7.3


