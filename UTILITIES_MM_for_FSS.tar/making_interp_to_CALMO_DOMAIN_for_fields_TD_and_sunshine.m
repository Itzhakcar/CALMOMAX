clear all
close all
extdir='/Research/models/CALMO1km/external_data/';
extfile=[extdir,'aggregated_LTUR_2013011000.nc'];
TDdir='/Research/models/CALMOMAX/DewPoint/';
latcalmo=ncread(extfile,'lat_1');
loncalmo=ncread(extfile,'lon_1');
load([TDdir,'Tdew_lat_of_swiss_DOMIAN.mat']);
load([TDdir,'Tdew_lon_of_swiss_DOMIAN.mat']);
load([TDdir,'sunshine_duration_DOMAIN_SWISS_lat1.mat']);
load([TDdir,'sunshine_duration_DOMAIN_SWISS_lon1.mat']);
load([TDdir,'sunshine.mat']);
XX=[];
for i=1:size(lat1,2)
    XX=[XX,mean(lat1(1:end,i))];
end
X=NaN(size(lat1,1),size(lat1,2));
for i=1:size(lat1,1)
    X(i,:)=XX;
end
YY=[];
for i=1:size(lon1,1)
    YY=[YY;mean(lon1(i,1:end))];
end
Y=NaN(size(lon1,1),size(lon1,2));
for i=1:size(lon1,2)
    Y(:,i)=YY;
end
xx2=[];
for i=1:size(latcalmo,2)
    xx2=[xx2,mean(latcalmo(1:end,i))];
end
x2=NaN(size(latcalmo,1),size(latcalmo,2));
for i=1:size(latcalmo,1)
    x2(i,:)=xx2;
end
yy2=[];
for i=1:size(loncalmo,1)
    yy2=[yy2;mean(loncalmo(i,1:end))];
end
y2=NaN(size(loncalmo,1),size(loncalmo,2));
for i=1:size(loncalmo,2)
    y2(:,i)=yy2;
end
XX=lat1(185,1:end);
YY=lon1(1:end,120);
xx2=latcalmo(579,1:end);
yy2=loncalmo(1:end,387);
VV=NaN(365,length(yy2),length(xx2));
for i=1:365
    MM=[];
    VV(i,:,:)=interp2(XX,YY,squeeze(sunshine(i,:,:)),xx2,yy2,'linear');
end
Mmean=NaN(365,size(VV,3));
for day=1:365
    for i=1:size(VV,3)
        Mmean(day,i)=nanmean(VV(182,:,i));
        
    end
end
Vmean=[];
for i=1:size(VV,3)
    Vmean=[Vmean,nanmean(Mmean(:,i))];
end
figure(1)
plot(xx2,Vmean,'r+-');grid on
title('2013 Sunshine field (longitudinal and annual mean). NaN does not count.')
ylabel('Sunshine field')
xlabel('Latitude (N)')
print('Sunshine_Field_on_2013_Latitude.png','-dpng')
Mmean=NaN(365,size(VV,2));
for day=1:365
    for i=1:size(VV,2)
        Mmean(day,i)=nanmean(VV(day,i,:));
    end
end
Vmean=[];
for i=1:size(VV,2)
    Vmean=[Vmean,nanmean(Mmean(:,i))];
end
figure(2)
plot(yy2,Vmean,'r+-');grid on
title('2013 Sunshine field (latitudinal and annual mean). NaN does not count.')
ylabel('Sunshine field')
xlabel('Longitude (E)')
print('Sunshine_Field_on_2013_Longitude.png','-dpng')
Aperc=[];
for itest=1:2000
ii=round(size(lat1,1)*rand+0.5);
jj=round(size(lon1,2)*rand+0.5);
dayday=round(365*rand+0.5);
%dayday=130;
KK=find(abs(lat1(ii,jj)-latcalmo(:))<=0.01 & abs(lon1(ii,jj)-loncalmo(:))<=0.01);
display('KK number of times')
    itest
    length(KK)
    lat1(ii,jj)
    lon1(ii,jj)
    latcalmo(KK)
    loncalmo(KK)

MM=squeeze(VV(dayday,:,:));
NN=squeeze(sunshine(dayday,:,:));
display('MM and NN')
MM(KK)
NN(ii,jj)
if(length(KK)>=1)
    Aperc=[Aperc;MM(KK(1)),NN(ii,jj),MM(KK(1)+1)-MM(KK(1)),NN(ii,jj+1)-NN(ii,jj)];
end
end

